import React, {} from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import styled from 'styled-components'


const ButtonLink = styled.button
`
    color: white;
     width: 70px;
     height: 30px;
     border:none;
     border:solid 2px white;
     border-radius: 5px;
     background: rgba(255, 255, 255,0);
     font-size: 10px;
     margin: 10px 20px;
     &:hover {
        border:solid 2px black;
        cursor: pointer;
        
      }
`

const useStyles = makeStyles(() => ({
    root: {
      flexGrow: 1,
      
    },
    title: {
      flexGrow: 0.9,
      fontFamily:
          'roboto',
          fontWeight: 70,
    },
  }));


export default function Heading(){
    const classes = useStyles();

    return(
        <div>
            <AppBar style={{ background: '#ff4d00' }}>
                <Toolbar >
                    <Typography  className={classes.title}>
                        Kelompok 1
                    </Typography>
                    <ButtonLink>
                            <a href="https://www.linkpicture.com/q/AGUUUNG.jpg">Agung</a>
                    </ButtonLink>
                    <ButtonLink >
                            <a href="https://i.ibb.co/SsjcNhB/3x4.jpg">Nobi</a>
                    </ButtonLink>
                </Toolbar>
            </AppBar>
        </div>
       
    )
}

